# Morphological Processing Task

This repository contains a Python implementation of morphological operations (erosion/dilation) on a collection of binary images.

## Task Description

The goal is to process a list of 2D binary arrays using morphological erosion or dilation with square kernels (sizes: 3, 5, 7). The solution also supports parallel processing using `multiprocessing` for better performance.

## How to Run

```bash
python morphology_task.py
```

## Dependencies

- numpy
- scipy
- matplotlib

Install them via:

```bash
pip install numpy scipy matplotlib
```

## Example Output

The script prints the original and eroded image in the console and displays a visual comparison using matplotlib.
